import os
import re
import json
import warnings
import threading
import uuid
import time
from datetime import datetime

import numpy as np
import pandas as pd
from pypdf import PdfReader
from flask import Flask, render_template, request, jsonify
import google.generativeai as genai

warnings.filterwarnings("ignore")

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = "uploads"
app.config["OUTPUT_FOLDER"] = "outputs"
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024

for d in [app.config["UPLOAD_FOLDER"], app.config["OUTPUT_FOLDER"]]:
    os.makedirs(d, exist_ok=True)

# Gemini Configuration
GEMINI_API_KEY = ""

# Try to configure Gemini
USE_LLM = False
gemini_model = None

if GEMINI_API_KEY:
    try:
        genai.configure(api_key=GEMINI_API_KEY)
        gemini_model = genai.GenerativeModel('gemini-flash-lite-latest')
        USE_LLM = True
        print("[LLM] Gemini client initialized successfully")
    except Exception as e:
        print(f"[LLM] Gemini API Init failed: {e}")
        print("[LLM] Continuing with regex-only extraction")
else:
    print("[LLM] No API key provided. Using regex-only extraction")

jobs = {}
_GLOBAL_ID = 0

# Scoring weights
WEIGHT_EDU = 0.35
WEIGHT_EXP = 0.35
WEIGHT_RES = 0.20
WEIGHT_COMP = 0.10

DEGREE_RANK = {
    'phd':5, 'ph.d':5, 'doctor of':5, 'doctorate':5, 'd.sc':5, 'postdoc':5,
    'mphil':4, 'm.phil':4, 'ms ':4, 'msc':4, 'm.sc':4, 'master':4, 'meng':4,
    'm.engg':4, 'mba':4, 'm.e.':4, 'm.e ':4, 'bachelor':3, 'bsc':3, 'b.sc':3,
    'bs ':3, 'be ':3, 'b.e':3, 'beng':3, 'b.eng':3, 'b.tech':3, 'btech':3,
    'hssc':2, 'fsc':2, 'f.sc':2, 'intermediate':2, 'a-level':2, 'a level':2,
    'higher secondary':2, 'pre-engineering':2, 'pre engineering':2, 'ssc':1,
    'matric':1, 'o-level':1, 'o level':1, 'secondary school':1, 'secondary':1,
    'primary':0,
}

MONTH_NUM = {'jan':1,'feb':2,'mar':3,'apr':4,'may':5,'jun':6,
             'jul':7,'aug':8,'sep':9,'oct':10,'nov':11,'dec':12}

# ============================================================
# PREPROCESSING MODULE - 
# ============================================================

def get_next_id():
    global _GLOBAL_ID
    _GLOBAL_ID += 1
    return _GLOBAL_ID

def reset_id_counter():
    global _GLOBAL_ID
    _GLOBAL_ID = 0

def read_pdf_pages(path):
    pages, errors = [], []
    try:
        reader = PdfReader(path)
        for pg_num, page in enumerate(reader.pages):
            try:
                text = page.extract_text()
                pages.append(text.strip() if text else '')
            except Exception as e:
                errors.append(f'Page {pg_num}: {e}')
                pages.append('')
    except Exception as e:
        errors.append(f'Cannot open PDF: {e}')
    return pages, errors

def clean_text(text):
    if not text:
        return ''
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', ' ', text)
    text = re.sub(r' {3,}', '  ', text)
    return text.strip()

def is_candidate_start(text):
    head = text[:600]
    if re.match(r'\s*Professional\s+Qualification', head, re.IGNORECASE):
        return True
    m = re.search(
        r'(?:^|\n)\s*Name\s+'
        r'(?!of\s+(?:Degree|Post|Contact|Qualification|Author|Organization|CO-Author))'
        r'([A-Z][A-Za-z]{1,})',
        head, re.MULTILINE
    )
    if m:
        mothers = re.search(r"Mother['s]*|Father['s]*", head, re.IGNORECASE)
        if mothers and (mothers.start() - m.start()) < 300:
            return True
    return False

def group_candidates(pages):
    candidates, current = [], []
    for page in pages:
        cleaned = clean_text(page)
        if not cleaned:
            continue
        if is_candidate_start(cleaned):
            if current:
                candidates.append('\n'.join(current))
            current = [cleaned]
        else:
            current.append(cleaned)
    if current:
        candidates.append('\n'.join(current))
    return candidates

def detect_pdf_type(candidates):
    n = len(candidates)
    if n > 1:
        return 'MULTI', f'{n} candidate boundaries detected'
    elif n == 1:
        return 'SINGLE', 'Single CV'
    else:
        return 'SINGLE', 'No boundaries found, treating as one'

# ============================================================
# EXTRACTION FUNCTIONS - 
# ============================================================

def get_field(pattern, text, default='N/A', group=1):
    try:
        m = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
        return m.group(group).strip() if m else default
    except Exception:
        return default

def clean_degree_name(raw):
    cleaned = re.sub(r'([a-z])([A-Z])', r'\1 \2', raw)
    cleaned = re.sub(r'([A-Z]{2,})([A-Z][a-z])', r'\1 \2', cleaned)
    cleaned = re.sub(r'\bPh\s+D\b', 'PhD', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    return cleaned

def merge_edu_lines(raw_section):
    lines = raw_section.split('\n')
    merged, buffer = [], ''
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if re.match(r'^(GPA|Passing|Year|Board|Specialization|Grade|%age)', line, re.IGNORECASE):
            continue
        if re.search(r'\b(19|20)\d{2}\b', line):
            buffer = (buffer + ' ' + line).strip() if buffer else line
            merged.append(buffer)
            buffer = ''
        else:
            buffer = (buffer + ' ' + line).strip() if buffer else line
    if buffer:
        merged.append(buffer)
    return merged

DEGREE_KEYWORDS = [
    'phd','ph.d','doctor','mphil','m.phil','ms ','msc','m.sc','master',
    'mba','meng','m.engg','m.e.','postdoc','bs ','bsc','b.sc','bachelor',
    'be ','b.e','b.eng','beng','hssc','fsc','f.sc','intermediate',
    'a-level','a level','ssc','s.sc','matric','o-level','o level',
    'secondary school','higher secondary','primary','diploma','d.a.e','dae',
    'certificate','engineering','engg','science','pre-eng','pre engineering'
]

def has_degree_keyword(line):
    t = line.lower()
    return any(k in t for k in DEGREE_KEYWORDS)

def get_degree_level(text):
    t = text.lower()
    best_rank, best_label = 0, 'Other'
    for key, rank in sorted(DEGREE_RANK.items(), key=lambda x: -len(x[0])):
        if key in t and rank > best_rank:
            best_rank = rank
            best_label = {
                5: 'PhD/PostDoc', 4: 'MS/MSc/MPhil', 3: 'BS/BSc/BE',
                2: 'HSSC/FSc', 1: 'SSC/Matric', 0: 'Primary'
            }[rank]
    return best_rank, best_label

def normalize_cgpa(val):
    if not val or val == 'N/A':
        return None
    try:
        raw = re.sub(r'/[\d\.]+', '', str(val))
        raw = raw.replace('%', '').replace(',', '')
        v = float(raw)
        if v > 100:
            return None
        if v >= 50:
            return round((v/100)*10, 2)
        if v <= 4.0:
            return round((v/4.0)*10, 2)
        if v <= 5.0:
            return round((v/5.0)*10, 2)
        return round(v, 2)
    except:
        return None

def parse_duration(dur_str):
    if not dur_str or dur_str == 'N/A':
        return None, None, 0
    try:
        pat = r'(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[\-/](\d{4})'
        dates = re.findall(pat, dur_str, re.I)
        present = bool(re.search(r'\bPresent\b', dur_str, re.I))
        cy, cm = datetime.now().year, datetime.now().month
        if len(dates) >= 2:
            sm = MONTH_NUM.get(dates[0][0][:3].lower(), 1)
            sy = int(dates[0][1])
            em = MONTH_NUM.get(dates[-1][0][:3].lower(), 12)
            ey = int(dates[-1][1])
            return sy, ey, max(0, (ey-sy)*12 + (em-sm))
        elif len(dates) == 1:
            sm = MONTH_NUM.get(dates[0][0][:3].lower(), 1)
            sy = int(dates[0][1])
            if present:
                return sy, cy, max(0, (cy-sy)*12 + (cm-sm))
    except:
        pass
    return None, None, 0

# ============================================================
# EXTRACTION FUNCTIONS - ALL REGEX ()
# ============================================================

def extract_personal(text, gid, source, seg_no, total_in_pdf):
    name = 'N/A'
    try:
        m = re.search(
            r'(?:^|\n)\s*Name\s+'
            r'(?!of\s+(?:Degree|Post|Contact|Qualification|Author|Organization|CO))'
            r'(.+?)(?:Father\'s|/Guardian)',
            text, re.IGNORECASE | re.DOTALL
        )
        if m:
            parts = []
            for line in m.group(1).split('\n'):
                line = line.strip()
                if not line:
                    continue
                if re.search(r'(Father|Guardian|Date|Spouse|Salary|Marital|Unit|Corps|SOD|SOS)',
                             line, re.IGNORECASE):
                    break
                parts.append(line)
            name = ' '.join(parts).strip()
            name = re.sub(r'\s*(Father|Guardian|Date|Spouse|Salary|Unit).*', '', name,
                          flags=re.IGNORECASE).strip()
    except Exception:
        pass
    
    dob = 'N/A'
    try:
        dob_m = re.search(r'Date/Place of\s*(?:\n\s*)?Birth:\s*([\d\-A-Za-z /\n]+)', text)
        if dob_m:
            raw = dob_m.group(1).replace('\n', ' ').strip()
            dob = raw.split('/')[0].strip().rstrip('/').strip()
            if not re.search(r'\d{4}', dob):
                dob = 'N/A'
    except Exception:
        pass
    
    employment = 'N/A'
    try:
        for pat in [
            r'Present\s*\nEmployment:\s*\n?(.*?)(?:\nServing|\nExpected)',
            r'Present\s+Employment:\s*(.*?)(?:\nServing|\nExpected|$)',
        ]:
            emp_m = re.search(pat, text, re.DOTALL | re.IGNORECASE)
            if emp_m:
                employment = emp_m.group(1).replace('\n', ' ').strip()
                break
    except Exception:
        pass
    
    email_m = re.search(r'([\w\.\+\-]+@[\w\.\-]+\.\w{2,})', text)
    email = email_m.group(1) if email_m else 'N/A'
    
    phone = 'N/A'
    for pat in [
        r'(?:Phone|Mobile|Cell)[:\s]+(\+?[\d\s\-\.]{8,})',
        r'(\+92[\s\-]?\d{3}[\s\-]?\d{7})',
        r'(0[0-9]{10})',
    ]:
        pm = re.search(pat, text, re.IGNORECASE)
        if pm:
            phone = pm.group(1).strip()
            break
    
    return {
        'candidate_id': gid,
        'Name': name if name else 'N/A',
        'Date of Birth': dob,
        'Marital Status': get_field(r'Marital Status[:\s]+(\w[\w\s\-]+?)(?:\n|Unit|SOD)', text),
        'Current Salary': get_field(r'Current Salary[:\s]+(\d[\d,\.]+)', text),
        'Expected Salary': get_field(r'Expected Salary[:\s]+(\d[\d,\.]+)', text),
        'Present Employment': employment,
        'Applying For': get_field(r'Candidate for the Post of\s+(.+?)(?:\s*\(Apply|\n)', text),
        'Apply Date': get_field(r'Apply Date[:\s]*([\d\-A-Za-z]+)', text),
        'Email': email,
        'Phone': phone,
        'Source File': source,
        'candidate_segment_no': seg_no,
        'total_candidates_in_pdf': total_in_pdf,
        'extracted_from_multi_cv': 'Yes' if total_in_pdf > 1 else 'No',
    }

def extract_education(text, cid):
    rows = []
    try:
        edu_m = re.search(
            r'Education\s*\nName of Degree\s+Specialization.+?\n(.*?)'
            r'(?:Candidate for the Post|Civil Experience|Professional Qualification\nCivil)',
            text, re.DOTALL | re.IGNORECASE
        )
        if not edu_m:
            return rows
        
        for line in merge_edu_lines(edu_m.group(1)):
            line = line.strip()
            if not line or len(line) < 5:
                continue
            if re.match(r'(Name of|Board/Uni|Passing|Speciali|Grade|^Degree)', line, re.IGNORECASE):
                continue
            year_m = re.search(r'\b(19|20)(\d{2})\b', line)
            if not year_m:
                continue
            if not has_degree_keyword(line):
                continue
            grade_m = re.search(r'(\d+\.\d+)%?\s*(?=(?:19|20)\d{2})', line)
            if not grade_m:
                grade_m = re.search(r'\b(\d{2,3}(?:\.\d+)?%?)\s+(?=(?:19|20)\d{2})', line)
            grade = grade_m.group(1).replace('%', '') if grade_m else 'N/A'
            raw_degree = line[:grade_m.start()].strip() if grade_m else line[:year_m.start()].strip()
            rows.append({
                'candidate_id': cid,
                'Degree/Details': clean_degree_name(raw_degree)[:120],
                'Year': year_m.group(0),
                'Grade/CGPA': grade
            })
    except Exception as e:
        rows.append({'candidate_id': cid, 'Degree/Details': f'[Error: {e}]',
                     'Year': 'N/A', 'Grade/CGPA': 'N/A'})
    return rows

def extract_prof_qual(text, cid):
    rows = []
    try:
        pq_m = re.search(
            r'Name of Qualification[:\s]*Passing Year[:\s]*Institution Name[:\s]*\n(.*?)'
            r'(?:Name of Post|Civil Experience\s*\nName|$)',
            text, re.DOTALL | re.IGNORECASE
        )
        if not pq_m:
            return rows
        for line in pq_m.group(1).split('\n'):
            line = line.strip()
            if not line or len(line) < 5:
                continue
            year_m = re.search(r'\b(19|20)\d{2}\b', line)
            rows.append({
                'candidate_id': cid,
                'Qualification': line[:150],
                'Year': year_m.group(0) if year_m else 'N/A'
            })
    except Exception:
        pass
    return rows

def extract_experience(text, cid):
    rows = []
    try:
        exp_m = re.search(
            r'Name\s+of\s+Post\s+Organization\s+Location\s+Duration\s+of\s+Employment\s*\n(.*?)'
            r'(?:Paper\s+Title|Research\s*\n?\s*Publications|Awards|References|Patents|$)',
            text, re.DOTALL | re.IGNORECASE
        )
        if not exp_m:
            return rows
        date_pat = r'(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[\-/](\d{4})'
        for line in exp_m.group(1).split('\n'):
            line = line.strip()
            if not line or len(line) < 5:
                continue
            has_present = bool(re.search(r'\bPresent\b', line, re.IGNORECASE))
            dates = re.findall(date_pat, line, re.IGNORECASE)
            if not dates and not has_present:
                continue
            date_idx = re.search(date_pat, line, re.IGNORECASE)
            role_org = line[:date_idx.start()].strip() if date_idx else line
            date_part = line[date_idx.start():].strip() if date_idx else 'Present'
            rows.append({
                'candidate_id': cid,
                'Position & Org': role_org[:120],
                'Duration': date_part[:60]
            })
    except Exception:
        pass
    return rows

def extract_publications(text, cid):
    rows = []
    try:
        pub_m = re.search(
            r'Paper\s+Title\s+Name\s+of\s+Author.+?\n(.*?)'
            r'(?:Name\s+Contact\s+Type|References?\s*\n\s*Name\s+Contact|$)',
            text, re.DOTALL | re.IGNORECASE
        )
        if not pub_m:
            return rows
        lines = pub_m.group(1).split('\n')
        year_pat = re.compile(r'^(20\d{2})$')
        month_pat = re.compile(r'^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-?$', re.I)
        journal_pat = re.compile(
            r'^(International Journal|International Conference|Journal|Conference|'
            r'IEEE|Springer|MDPI|Elsevier|ACM|Wiley|Hindawi|Sensors|Electronics|'
            r'Energies|Applied|Computers|IEEE Access|Scientific Reports)', re.I
        )
        impact_pat = re.compile(r'\b(\d+\.\d+)\b')
        
        groups, cur = [], []
        for line in lines:
            line = line.strip()
            if not line:
                continue
            if re.match(r'(Name of|Paper Title|Factor|^Vol$|^PP$|^Date$)', line, re.I):
                continue
            cur.append(line)
            if year_pat.match(line):
                groups.append(cur[:])
                cur = []
        if cur:
            groups.append(cur)
        
        for grp in groups:
            if not grp:
                continue
            jidx = -1
            for idx, l in enumerate(grp):
                if impact_pat.search(l) or journal_pat.match(l):
                    jidx = idx
                    break
            if jidx < 0:
                continue
            title = ' '.join(grp[:jidx]).strip()
            jline = grp[jidx]
            mo, yr = '', ''
            for l in grp[jidx+1:]:
                if month_pat.match(l):
                    mo = l.replace('-', '').strip()
                if year_pat.match(l):
                    yr = l.strip()
            inline = re.search(r'(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-?(\d{4})',
                                jline, re.I)
            if inline:
                mo, yr = inline.group(1), inline.group(2)
            date_s = f'{mo}-{yr}' if mo and yr else (yr if yr else 'N/A')
            im = impact_pat.search(jline)
            rows.append({
                'candidate_id': cid,
                'Title': title[:200],
                'Published In': jline[:100],
                'Impact Factor': im.group(1) if im else 'N/A',
                'Date': date_s
            })
    except Exception:
        pass
    return rows

def extract_awards(text, cid):
    rows = []
    try:
        aw_m = re.search(
            r'Awards\s*[&and]*\s*Scholarships?\s*\n(?:Type\s+Detail\s*\n)?'
            r'(.*?)(?:References?\s*\nName|Patents?\s*\n|Research Publications|Paper Title|$)',
            text, re.DOTALL | re.IGNORECASE
        )
        if not aw_m:
            return rows
        section = aw_m.group(1)
        ref_stop = re.search(r'\bReferences?\b', section, re.IGNORECASE)
        if ref_stop:
            section = section[:ref_stop.start()]
        for entry in re.split(r'\n(?=(?:Merit Scholarships?|Academic Awards?|Membership)\s)', section):
            entry = entry.strip()
            if len(entry) < 5:
                continue
            type_m = re.match(r'(Merit Scholarships?|Academic Awards?|Membership)\s+(.*)',
                              entry, re.DOTALL)
            rows.append({
                'candidate_id': cid,
                'Type': type_m.group(1).strip() if type_m else 'Other',
                'Detail': (type_m.group(2) if type_m else entry).replace('\n', ' ').strip()[:300]
            })
    except Exception:
        pass
    return rows

def extract_patents(text, cid):
    rows = []
    try:
        pat_m = re.search(
            r'\bPatents?\b\s*\n(?:No\.?\s+Patent Title\s*\n)?(.*?)'
            r'(?:\bReferences?\b\s*\nName|\bAwards\b|$)',
            text, re.DOTALL | re.IGNORECASE
        )
        if not pat_m:
            return rows
        pt = pat_m.group(1).strip()
        if re.match(r'^(NA|N/A|0\s+NA|No\s+NA)\s*$', pt, re.IGNORECASE):
            return rows
        full = pt.replace('\n', ' ')
        if re.search(r'(Impact Factor|Vol PP Date|Paper Title)', full, re.IGNORECASE):
            return rows
        for entry in re.split(r'(?=GE-?\d+|\b\d+\.\s+[A-Z])', full):
            entry = entry.strip()
            if len(entry) > 10 and not re.match(r'^(NA|N/A|0|No)\s*$', entry, re.IGNORECASE):
                rows.append({'candidate_id': cid, 'Patent Details': entry[:300]})
    except Exception:
        pass
    return rows

def extract_references(text, cid):
    rows = []
    try:
        ref_m = None
        for pat in [
            r'Name\s+Contact\s*\nType\s+Designation\s+Address.+?\n(.*?)$',
            r'Name\s+Contact\s+Type\s+Designation\s+Address.+?\n(.*?)$',
        ]:
            ref_m = re.search(pat, text, re.DOTALL | re.IGNORECASE)
            if ref_m:
                break
        if not ref_m:
            return rows
        entries = re.findall(
            r'([A-Z][\w\.\s,]+?)\s*Reference\s+(.+?)(?=(?:[A-Z][\w\.\s,]+?\s*Reference)|$)',
            ref_m.group(1), re.DOTALL
        )
        for name, details in entries:
            d = details.replace('\n', ' ').strip()
            em = re.search(r'[\w\.\-]+@[\w\.\-]+\.\w+', d)
            ph = re.search(r'(\+?\d[\d\s\-]{6,})', d)
            rows.append({'candidate_id': cid, 'Ref Name': name.strip()[:80],
                         'Details': d[:200], 'Email': em.group(0) if em else 'N/A',
                         'Phone': ph.group(1).strip() if ph else 'N/A'})
    except Exception:
        pass
    return rows

def extract_skills(text, cid):
    SKILLS = [
        'Python','MATLAB','C\\+\\+','Java','JavaScript','Machine Learning',
        'Deep Learning','NLP','Computer Vision','TensorFlow','PyTorch','Keras',
        'Signal Processing','Wireless Communication','OFDM','5G','LTE','4G',
        'Embedded Systems','FPGA','Arduino','VHDL','Verilog','SIMULINK',
        'Data Analysis','Power Systems','Control Systems','Communication Systems',
        'Antenna Design','IoT','Cloud Computing','Blockchain','LabVIEW','AutoCAD',
        'LaTeX','SQL','R Programming','OpenCV','Reinforcement Learning'
    ]
    found = [re.sub(r'\\', '', s) for s in SKILLS
             if re.search(r'\b' + s + r'\b', text, re.IGNORECASE)]
    return {
        'candidate_id': cid,
        'Skills Found': ', '.join(found) if found else 'N/A',
        'Skill Count': len(found)
    }

# ============================================================
# ANALYSIS FUNCTIONS
# ============================================================

def analyze_education_profile(edu_records):
    if not edu_records:
        return {
            "highest_degree": "None",
            "degree_rank": 0,
            "degree_path": "N/A",
            "total_degrees": 0,
            "avg_cgpa": 0.0,
            "edu_score": 0.0
        }
    
    highest_rank, highest_label = 0, "None"
    degree_list, year_list, cgpa_norm_list = [], [], []
    
    for rec in edu_records:
        rank, lbl = get_degree_level(str(rec.get("Degree/Details", "")))
        if rank > highest_rank:
            highest_rank, highest_label = rank, lbl
        degree_list.append(lbl)
        
        try:
            y = int(str(rec.get("Year", 0))[:4])
            if 1900 < y < 2100:
                year_list.append(y)
        except:
            pass
        
        norm = normalize_cgpa(rec.get("Grade/CGPA", "N/A"))
        if norm is not None:
            cgpa_norm_list.append(norm)
    
    edu_gap = (sorted(year_list)[-1] - sorted(year_list)[0]) if len(year_list) >= 2 else 0
    missed_years = sum(1 for e in edu_records if e.get("Year") == "N/A")
    missed_cgpa = sum(1 for e in edu_records if e.get("Grade/CGPA") == "N/A")
    avg_cgpa = round(float(np.mean(cgpa_norm_list)), 2) if cgpa_norm_list else 0.0
    
    deg_pts = min(5.0, highest_rank)
    cgpa_pts = round((avg_cgpa / 10) * 3, 2)
    comp_pts = max(0.0, 2.0 - (missed_years + missed_cgpa) * 0.3)
    edu_score = min(10.0, round(deg_pts + cgpa_pts + comp_pts, 2))
    
    seen, uniq = set(), []
    for d in degree_list[::-1]:
        if d not in seen:
            seen.add(d)
            uniq.append(d)
    
    return {
        "highest_degree": highest_label,
        "degree_rank": highest_rank,
        "degree_path": " → ".join(uniq) if uniq else "N/A",
        "total_degrees": len(degree_list),
        "avg_cgpa": avg_cgpa,
        "education_span_years": edu_gap,
        "missing_year_count": missed_years,
        "missing_cgpa_count": missed_cgpa,
        "edu_score": edu_score
    }

def analyze_experience_profile(exp_records):
    if not exp_records:
        return {
            "total_exp_years": 0,
            "job_count": 0,
            "has_overlap": "No",
            "employment_gap_years": 0,
            "exp_score": 0.0
        }
    
    total_months = 0
    for rec in exp_records:
        s, e, m = parse_duration(rec.get("Duration", ""))
        total_months += m
    
    total_years = round(total_months / 12, 1)
    job_count = len(exp_records)
    
    dates = []
    for rec in exp_records:
        dur = rec.get("Duration", "")
        dates_found = re.findall(r'(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[\-/](\d{4})', dur, re.I)
        if len(dates_found) >= 2:
            dates.append((int(dates_found[0][1]), int(dates_found[-1][1])))
    
    overlap = "No"
    for i in range(len(dates)):
        for j in range(i+1, len(dates)):
            if dates[i][1] > dates[j][0] and dates[j][1] > dates[i][0]:
                overlap = "Yes"
                break
    
    gap_years = 0
    if len(dates) >= 2:
        sorted_dates = sorted(dates, key=lambda x: x[0])
        for i in range(1, len(sorted_dates)):
            gap = sorted_dates[i][0] - sorted_dates[i-1][1]
            if gap > 1:
                gap_years += gap
    
    exp_score = 0.0
    if total_years >= 10:
        exp_score = 9.0
    elif total_years >= 5:
        exp_score = 7.0
    elif total_years >= 2:
        exp_score = 5.0
    elif total_years >= 0.5:
        exp_score = 2.0
    
    exp_score = min(10.0, exp_score + min(1.0, job_count * 0.2))
    if overlap == "Yes":
        exp_score = max(0.0, exp_score - 0.5)
    if gap_years > 2:
        exp_score = max(0.0, exp_score - 0.5)
    
    return {
        "total_exp_years": total_years,
        "job_count": job_count,
        "has_overlap": overlap,
        "employment_gap_years": gap_years,
        "exp_score": round(exp_score, 2)
    }

def analyze_research_profile(pub_records):
    if not pub_records:
        return {
            "total_publications": 0,
            "journal_count": 0,
            "conference_count": 0,
            "avg_impact_factor": 0.0,
            "max_impact_factor": 0.0,
            "research_score": 0.0,
            "research_activity": "No Publications"
        }
    
    journal_count = 0
    conference_count = 0
    ifs = []
    
    for pub in pub_records:
        venue = pub.get("Published In", "").lower()
        if "journal" in venue:
            journal_count += 1
        elif "conference" in venue or "proc" in venue:
            conference_count += 1
        
        try:
            cv_if = float(pub.get("Impact Factor", "0"))
            if cv_if > 0:
                ifs.append(cv_if)
        except:
            pass
    
    avg_if = round(float(np.mean(ifs)), 2) if ifs else 0.0
    max_if = round(float(max(ifs)), 2) if ifs else 0.0
    
    years = []
    for p in pub_records:
        yr_match = re.search(r'(20\d{2})', str(p.get("Date", "")))
        if yr_match:
            years.append(int(yr_match.group(1)))
    
    current_year = datetime.now().year
    if years:
        last_year = max(years)
        yrs_since = current_year - last_year
        if yrs_since <= 1:
            activity = "Highly Active"
        elif yrs_since <= 3:
            activity = "Active"
        elif yrs_since <= 6:
            activity = "Moderate"
        else:
            activity = "Inactive"
    else:
        activity = "No Publications"
    
    n = len(pub_records)
    rscore = min(4.0, n * 0.4) + min(3.0, avg_if * 0.8)
    activity_score = {"Highly Active": 2, "Active": 1.5, "Moderate": 1, 
                      "Inactive": 0, "No Publications": 0, "No Data": 0}.get(activity, 0)
    rscore += activity_score
    rscore = min(rscore, 10.0)
    
    return {
        "total_publications": n,
        "journal_count": journal_count,
        "conference_count": conference_count,
        "avg_impact_factor": avg_if,
        "max_impact_factor": max_if,
        "latest_pub_year": str(max(years)) if years else "N/A",
        "research_activity": activity,
        "research_score": round(rscore, 2)
    }

# ============================================================
# MISSING INFO AND COMPLETENESS ()
# ============================================================

def detect_missing_info(personal, edu_records, exp_records, pub_records):
    issues = []
    na = lambda v: not v or str(v).strip().lower() in ['n/a', 'none', '', 'nan']
    
    if na(personal.get('Email', 'N/A')):
        issues.append('Missing Email')
    if na(personal.get('Phone', 'N/A')):
        issues.append('Missing Phone')
    if na(personal.get('Date of Birth', 'N/A')):
        issues.append('Missing Date of Birth')
    if na(personal.get('Present Employment', 'N/A')):
        issues.append('Missing Employment Info')
    
    if not edu_records:
        issues.append('No Education Records')
    else:
        my = sum(1 for e in edu_records if e.get('Year') == 'N/A')
        mc = sum(1 for e in edu_records if e.get('Grade/CGPA') == 'N/A')
        if my > 0:
            issues.append(f'{int(my)} Education Record(s) Missing Year')
        if mc > 0:
            issues.append(f'{int(mc)} Education Record(s) Missing CGPA')
    
    if not exp_records:
        issues.append('No Experience Records')
    
    if not pub_records:
        issues.append('No Publications')
    else:
        md = sum(1 for p in pub_records if p.get('Date') == 'N/A')
        mi = sum(1 for p in pub_records if p.get('Impact Factor') == 'N/A')
        if md > 0:
            issues.append(f'{int(md)} Publication(s) Missing Date')
        if mi > 0:
            issues.append(f'{int(mi)} Publication(s) Missing Impact Factor')
    
    completeness = max(0.0, round(10.0 - len(issues) * 0.8, 2))
    return completeness, issues

# ============================================================
# EMAIL DRAFTS
# ============================================================

def draft_email(candidate_name, missing_items):
    if not missing_items:
        return ""
    items_text = "\n".join(f"  - {item}" for item in missing_items)
    return (
        f"Subject: Application Update Request -- {candidate_name}\n\n"
        f"Dear {candidate_name},\n\n"
        f"Thank you for submitting your application. After reviewing your CV, "
        f"we found that the following information is missing or incomplete:\n\n"
        f"{items_text}\n\n"
        f"We kindly request that you provide the above details at your earliest convenience "
        f"so that we may proceed with the evaluation of your application.\n\n"
        f"Best regards,\n"
        f"TALASH Recruitment System"
    )

def draft_shortlist_email(candidate_name, rank):
    return (
        f"Subject: TALASH Application - You Have Been Shortlisted -- {candidate_name}\n\n"
        f"Dear {candidate_name},\n\n"
        f"We are pleased to inform you that your application has been "
        f"shortlisted (Rank #{rank}).\n\n"
        f"Please confirm your availability for an interview by replying to this email.\n\n"
        f"Best regards,\n"
        f"TALASH Recruitment System"
    )

def draft_rejection_email(candidate_name):
    return (
        f"Subject: TALASH Application - Outcome Notification -- {candidate_name}\n\n"
        f"Dear {candidate_name},\n\n"
        f"Thank you for your interest. After careful evaluation we are "
        f"unable to proceed with your application at this time.\n\n"
        f"We encourage you to apply again in future openings.\n\n"
        f"Best regards,\n"
        f"TALASH Recruitment System"
    )

# ============================================================
# MAIN PROCESSING FUNCTION -  
# ============================================================

def process_single_cv(text, gid, source_name, seg_no, total_in_pdf):
    """Process a single candidate's CV text block - follows notebook logic exactly"""
    
    personal = extract_personal(text, gid, source_name, seg_no, total_in_pdf)
    
    # CRITICAL: Skip blank candidate - 
    if personal['Name'] == 'N/A' and personal['Date of Birth'] == 'N/A' and personal['Current Salary'] == 'N/A':
        return None
    
    # Extract all sections using regex
    edu = extract_education(text, gid)
    prof_qual = extract_prof_qual(text, gid)
    exp = extract_experience(text, gid)
    pubs = extract_publications(text, gid)
    awards = extract_awards(text, gid)
    patents = extract_patents(text, gid)
    references = extract_references(text, gid)
    skills = extract_skills(text, gid)
    
    # Calculate scores
    completeness_score, missing = detect_missing_info(personal, edu, exp, pubs)
    
    edu_analysis = analyze_education_profile(edu)
    exp_analysis = analyze_experience_profile(exp)
    res_analysis = analyze_research_profile(pubs)
    
    edu_score = edu_analysis["edu_score"]
    exp_score = exp_analysis["exp_score"]
    res_score = res_analysis["research_score"]
    
    final_score = round(
        WEIGHT_EDU * edu_score
        + WEIGHT_EXP * exp_score
        + WEIGHT_RES * res_score
        + WEIGHT_COMP * completeness_score,
        2,
    )
    
    # Determine recommendation
    if final_score >= 7.5:
        recommendation = "Strong Shortlist"
    elif final_score >= 5.5:
        recommendation = "Shortlist"
    elif final_score >= 3.5:
        recommendation = "Review"
    else:
        recommendation = "Reject"
    
    return {
        "personal": personal,
        "education": edu,
        "prof_qual": prof_qual,
        "experience": exp,
        "publications": pubs,
        "awards": awards,
        "patents": patents,
        "references": references,
        "skills": skills,
        "missing_info": missing,
        "edu_analysis": edu_analysis,
        "exp_analysis": exp_analysis,
        "res_analysis": res_analysis,
        "scores": {
            "edu_score": edu_score,
            "exp_score": exp_score,
            "res_score": res_score,
            "comp_score": completeness_score,
            "final_score": final_score,
            "recommendation": recommendation,
        },
    }

# ============================================================
# FLASK ROUTES
# ============================================================

def run_pipeline(job_id, pdf_paths):
    job = jobs[job_id]
    job["status"] = "running"
    job["log"] = []
    all_candidates = []
    reset_id_counter()

    for pdf_path in pdf_paths:
        fname = os.path.basename(pdf_path)
        job["log"].append(f"Reading {fname}...")
        pages, errors = read_pdf_pages(pdf_path)
        for err in errors[:3]:
            job["log"].append(f"  Warning: {err}")

        if not pages:
            job["log"].append(f"  Could not read {fname}, skipping.")
            continue
        
        candidates = group_candidates(pages)
        total_in_pdf = len(candidates) if candidates else 1
        pdf_type, reason = detect_pdf_type(candidates)
        job["log"].append(f"  PDF Type: {pdf_type} ({reason})")
        
        if not candidates:
            candidates = [clean_text(' '.join(pages))]
            total_in_pdf = 1
            job["log"].append("  No boundaries found - entire PDF treated as one candidate")
        
        bound_count = len(candidates)
        job["log"].append(f"  Found {bound_count} candidate boundaries in {fname}")

        for seg_idx, block in enumerate(candidates, 1):
            gid = get_next_id()
            
            nm = re.search(r'Name\s+([A-Z][A-Za-z ]{2,35})(?:\n|Father)', block[:400])
            label = nm.group(1).strip() if nm else f'Unknown_{gid}'
            
            job["log"].append(f"  [{seg_idx:02d}] ID={gid:03d} -> {label[:45]}")
            result = process_single_cv(block, gid, fname, seg_idx, total_in_pdf)
            
            if result is None:
                job["log"].append(f"      [SKIP] No personal data found")
                continue
            
            all_candidates.append(result)
            name = result["personal"].get("Name", f"Candidate {gid}")
            job["log"].append(f"      Name: {name}")
            job["log"].append(f"      Education: {len(result['education'])} records")
            job["log"].append(f"      Experience: {len(result['experience'])} records")
            job["log"].append(f"      Publications: {len(result['publications'])} records")
            
            # Small delay to avoid rate limits
            time.sleep(0.5)

    if not all_candidates:
        job["log"].append("No valid candidates found in any PDF.")
        job["status"] = "done"
        job["candidates"] = []
        job["candidate_count"] = 0
        return

    # Sort by final score and assign ranks
    all_candidates.sort(key=lambda c: c["scores"]["final_score"], reverse=True)
    for rank, c in enumerate(all_candidates, 1):
        c["rank"] = rank
        # Generate email if missing info
        if c["missing_info"]:
            c["email_draft"] = draft_email(c["personal"]["Name"], c["missing_info"])
        elif c["scores"]["recommendation"] == "Strong Shortlist":
            c["email_draft"] = draft_shortlist_email(c["personal"]["Name"], rank)
        elif c["scores"]["recommendation"] == "Reject":
            c["email_draft"] = draft_rejection_email(c["personal"]["Name"])
        else:
            c["email_draft"] = ""

    job["candidates"] = all_candidates
    job["status"] = "done"
    job["candidate_count"] = len(all_candidates)
    job["log"].append(f"Pipeline complete. {len(all_candidates)} candidates processed.")
    job["log"].append(f"NOTE: {bound_count} boundaries detected, {len(all_candidates)} valid candidates (others had no personal data)")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload():
    files = request.files.getlist("cvs")
    if not files or not any(f.filename for f in files):
        return jsonify({"error": "No files uploaded"}), 400

    job_id = str(uuid.uuid4())[:8]
    saved_paths = []
    for f in files:
        if f.filename and f.filename.lower().endswith(".pdf"):
            safe_name = re.sub(r"[^\w\.\-]", "_", f.filename)
            dest = os.path.join(app.config["UPLOAD_FOLDER"], f"{job_id}_{safe_name}")
            f.save(dest)
            saved_paths.append(dest)

    if not saved_paths:
        return jsonify({"error": "No valid PDF files found"}), 400

    jobs[job_id] = {"status": "queued", "log": [], "candidates": [], "candidate_count": 0}
    t = threading.Thread(target=run_pipeline, args=(job_id, saved_paths), daemon=True)
    t.start()
    return jsonify({"job_id": job_id})

@app.route("/status/<job_id>")
def status(job_id):
    job = jobs.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404
    return jsonify({
        "status": job["status"],
        "log": job["log"],
        "candidate_count": job.get("candidate_count", 0),
    })

@app.route("/results/<job_id>")
def results(job_id):
    job = jobs.get(job_id)
    if not job or job["status"] != "done":
        return jsonify({"error": "Results not ready"}), 404

    candidates = job["candidates"]
    summary = {
        "total": len(candidates),
        "strong_shortlist": sum(1 for c in candidates if c["scores"]["recommendation"] == "Strong Shortlist"),
        "shortlist": sum(1 for c in candidates if c["scores"]["recommendation"] == "Shortlist"),
        "review": sum(1 for c in candidates if c["scores"]["recommendation"] == "Review"),
        "reject": sum(1 for c in candidates if c["scores"]["recommendation"] == "Reject"),
    }

    candidate_list = []
    for c in candidates:
        candidate_list.append({
            "rank": c["rank"],
            "id": c["personal"]["candidate_id"],
            "name": c["personal"]["Name"],
            "email": c["personal"]["Email"],
            "phone": c["personal"]["Phone"],
            "employment": c["personal"]["Present Employment"],
            "source": c["personal"]["Source File"],
            "highest_degree": c["edu_analysis"]["highest_degree"],
            "total_exp_years": c["exp_analysis"]["total_exp_years"],
            "pub_count": c["res_analysis"]["total_publications"],
            "journal_count": c["res_analysis"]["journal_count"],
            "edu_score": c["scores"]["edu_score"],
            "exp_score": c["scores"]["exp_score"],
            "res_score": c["scores"]["res_score"],
            "comp_score": c["scores"]["comp_score"],
            "final_score": c["scores"]["final_score"],
            "recommendation": c["scores"]["recommendation"],
            "missing_info": c["missing_info"],
            "has_email_draft": bool(c.get("email_draft", "")),
        })

    return jsonify({"summary": summary, "candidates": candidate_list})

@app.route("/candidate/<job_id>/<int:candidate_id>")
def candidate_detail(job_id, candidate_id):
    job = jobs.get(job_id)
    if not job or job["status"] != "done":
        return jsonify({"error": "Not ready"}), 404

    for c in job["candidates"]:
        if c["personal"]["candidate_id"] == candidate_id:
            return jsonify({
                "personal": c["personal"],
                "education": c["education"],
                "prof_qual": c["prof_qual"],
                "experience": c["experience"],
                "publications": c["publications"],
                "awards": c["awards"],
                "patents": c["patents"],
                "references": c["references"],
                "skills": c["skills"],
                "missing_info": c["missing_info"],
                "email_draft": c.get("email_draft", ""),
                "edu_analysis": c["edu_analysis"],
                "exp_analysis": c["exp_analysis"],
                "res_analysis": c["res_analysis"],
                "scores": c["scores"],
                "rank": c["rank"],
            })
    return jsonify({"error": "Candidate not found"}), 404

if __name__ == "__main__":
    print("=" * 60)
    print("TALASH Recruitment System")
    print("=" * 60)
    print(f"LLM Mode: {USE_LLM}")
    print("\nProcessing Logic:")
    print("  - PDFs are split by candidate boundaries")
    print("  - Each candidate block is processed")
    print("  - Candidates with no personal data are skipped")
    print("  - Final count = valid candidates only")
    print("=" * 60)
    print("Starting server on http://localhost:5050")
    app.run(debug=True, port=5050)